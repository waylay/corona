<?php

return [
    'city'        => 'Halifax',
    'location'    => 'LA RUE ARGYLE À HALIFAX',
    'date'        => 'LE 11 AOÛT, DE 18 H À MINUIT',
    'address'     => '1732, rue Argyle<br>Halifax (N.-É.)<br>Entrée au coin des rues Argyle et Prince',
    'description' => 'Tout le pays aura les yeux rivés sur Halifax lors du coup d’envoi du National Corona Sunsets Festival sur la côte est. À l’occasion de ce premier festival en plein air qui se tiendra sur la rue Argyle à Halifax, nous occuperons un pâté de maisons en entier, ralliant certains des endroits de prédilection du centre-ville comme The Auction House, The Five Fisherman et The Dome.<br><br>Le 11 août, joignez-vous à nous en plein cœur des Maritimes pour le premier de nos cinq festivals.',
];
