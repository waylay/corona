<?php

return [
    'city'        => 'QUÉBEC',
    'location'    => 'DÉLICE',
    'date'        => 'LE 11 AOÛT, DE 18 H À 23 H EDT',    
    'address'     => '146, route du Président-Kennedy<br>Lévis (QC) G6V 6C9',
    'description' => 'Admirez les scènes de couchers de soleil qui illumineront la ville de Québec lors de notre festival en plein air Corona Sunsets Festival qui unira le Canada d’est en ouest.<br><br>Le 11 août, nous serons en direct du Délice, l’établissement de vie nocturne le plus fréquenté de Lévis, pour célébrer leur plus grand événement à ce our.',
];
