<?php

return [
    'city'        => 'Toronto',
    'location'    => 'PAVILION SUNNYSIDE',
    'date'        => 'LE 11 AOÛT, DE 18 H À 23 H (HNE)',
    'address'     => '1755, Lake Shore Blvd W<br>Toronto (ON) M6S 5A3',
    'description' => 'Rendez-vous au cœur de l’action pour célébrer le festival national des couchers de soleil! Rejoignez-nous à Toronto pour passer la soirée avec quelques- uns des meilleurs artistes du monde qui se produiront sur de magnifiques scènes intimes du centre-ville.<br><br>Le 11 août, venez assister aux performances en direct sur le plus beau site en plein air de la ville: le Pavilion Sunnyside.',
];
