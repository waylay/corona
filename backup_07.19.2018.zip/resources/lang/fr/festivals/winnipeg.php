<?php

return [
    'city'        => 'Winnipeg',
    'location'    => 'LE TAVERN UNITED AU CENTRE-VILLE DE WINNIPEG',
    'date'        => 'LE 11 AOÛT, DE 18 H À MINUIT HAC',    
    'address'     => '260, rue Hargrave Winnipeg (MB) R3C 5S5',
    'description' => 'Alors que nous célébrons le soleil couchant et nos performances qui s’enchaînent d’un océan à l’autre, nous ferons la fête dans les Prairies pour admirer la vue imprenable sur Winnipeg tout en partageant avec tout le pays ce qui a été proclamé comme « la meilleure terrasse de la ville ».<br><br>Le 11 août, joignez-vous au Corona Sunsets Festival en direct du centre-ville, au Tavern United.',
];
