<?php

return [
    'city'        => 'Toronto',
    'location'    => 'Sunnyside Pavilion',
    'date'        => 'Aug 11th - 6PM-11PM EDT',
    'address'     => '1755 Lake Shore Blvd W<br>Toronto, ON M6S 5A3',
    'description' => 'Celebrate the Corona sunsets festival from its centre – join us in Toronto as we usher in the night with some of the world’s best artists performing amazing intimate sets from the waterfront downtown.<br><br>Catch the action live Aug 11 th from the city’s most stunning open air venue – Sunnyside Pavilion.',
];
