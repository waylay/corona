<?php

return [
    'city'        => 'Winnipeg',
    'location'    => 'TAVERN UNITED DOWNTOWN',
    'date'        => 'AUGUST 11TH – 6PM-12AM CDT',
    'address'     => '260 Hargrave St, Winnipeg, MB R3C 5S5',
    'description' => 'As we celebrate the setting sun and our performances cascade coast to coast, we’ll be partying in the prairies to take in the Winnipeg vista views while we share what’s been voted “the best patio in town” with the whole country.<br><br>Join us for the Corona Sunsets Festival live August 11th from the heart of the city – Tavern United Downtown.',
];
