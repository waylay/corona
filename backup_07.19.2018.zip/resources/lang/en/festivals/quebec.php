<?php

return [
    'city'        => 'Quebec City',
    'location'    => 'DELICE',
    'date'        => 'Aug 11th - 6PM-11PM EDT',
    'address'     => '146 Kennedy Street<br>Lévis, QC G6V 6C9',
    'description' => 'Take in the sunset scenes as they crest over Quebec City during our nationally-connected Corona Sunsets Festival under the open-air.<br><br>We’ll be live August 11th from Levis’ number one nightlife music venue for their biggest celebration yet - at Delice.',
];
