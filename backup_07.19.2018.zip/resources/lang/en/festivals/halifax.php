<?php

return [
    'city'        => 'Halifax',
    'location'    => 'ARGYLE STREET',
    'date'        => 'Aug 11th - 6PM-12AM ADT',
    'address'     => '1732 Argyle St, Halifax, NS<br>Entrance on the corner of Argyle St & Prince St',
    'description' => 'The whole country will be watching Halifax as we kick off the national Corona Sunsets Festival on the East Coast. We’re rallying some of the city’s favourite downtown spots like The Auction House, The Five Fisherman, and The Dome to takeover a whole block - Halifax’s first open-air festival from Argyle Street.<br><br>Join us August 11th with the first of our five festivals in the heart of the Maritimes.',
];
