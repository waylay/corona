@component('mail::message')
# {{ trans('email.heading') }}
<br>
## {{ trans('email.text-1') }}
@endcomponent
