<tr>
    <td class="header">
        <a href="<?php echo e(config('app.url')); ?>">
            <img src="<?php echo e(url('/images/email_header.jpg')); ?>" style="margin: 0; border: 0; padding: 0; display: block;" width="600" height="328">
        </a>
    </td>
</tr>