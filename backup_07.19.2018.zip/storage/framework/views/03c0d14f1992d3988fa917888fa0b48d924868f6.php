<?php $__env->startSection('content'); ?>

<div class="container-fluid message" id="thankyou">
    
   

    <div class="container">
        <div class="row">
        
            <h1 class="secondary"><?php echo e(trans('text.thankyou')); ?></h1>
            <h2><?php echo trans('text.allset'); ?> </h2>
    
        </div>
    </div> <!-- END .row -->

    
    
</div> <!-- END #festival -->



<div class="festival-list-wrapper">
    <div class="container-fluid" id="festival-list">
        <div class="row">
            <ul class="list-inline">
            <?php $__currentLoopData = $festivals; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slug => $festival): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><a href="#slide-<?php echo e($festival['id']); ?>" data-slide="<?php echo e($festival['id'] + 1); ?>"><?php echo e(trans('festivals/'.$festival['slug'].'.city')); ?></a></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    </div>  <!-- END #festival-list -->
</div>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>