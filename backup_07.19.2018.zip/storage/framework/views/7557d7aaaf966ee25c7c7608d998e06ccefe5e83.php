<?php $__env->startSection('content'); ?>

<div class="container-fluid message" id="underage">
    
    <h1><?php echo trans('text.sorry'); ?></h1>
    <h1 class="secondary"><?php echo trans('text.underage'); ?> </h1>
    
</div> <!-- END #underage -->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>