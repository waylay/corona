<?php $__env->startSection('content'); ?>

<div class="learn-more-wrapper">
    <div class="container-fluid">
        <h1><?php echo trans('text.learn-more-title'); ?></h1>
        <h2><?php echo trans('text.learn-more-subtitle'); ?> </h2>
        <p><?php echo trans('text.learn-more-text'); ?> </p>
        <ul class="list-inline">
            <?php $__currentLoopData = $festivals; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slug => $festival): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><a href="/festival/<?php echo e($slug); ?> "><?php echo e(trans('festivals/'.$festival['slug'].'.city')); ?></a></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
        <a href="https://twitter.com/hashtag/coronasunsetsCA" target="_blank">#coronasunsetsCA</a>
    </div>    
</div> <!-- END #learn-more -->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>