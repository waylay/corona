<?php $__env->startSection('content'); ?>

<div class="festival-wrapper"  <?php if(isset($festival_background)): ?> <?php echo $festival_background; ?> <?php endif; ?> >

    <div class="festival-header container-fluid">
        
        <div class="festival-city">
            <h1><?php echo e(trans('festivals/'.$festival['slug'].'.city')); ?></h1>
        </div>
        <div class="festival-date-location">
        <?php if($festival['link']): ?> <a href="<?php echo e($festival['link']); ?>" target="_blank"> <?php endif; ?>
            <p><?php echo e(trans('festivals/'.$festival['slug'].'.location')); ?></p>
            <p><?php echo e(trans('festivals/'.$festival['slug'].'.date')); ?></p>
        <?php if($festival['link']): ?> </a>  <?php endif; ?>
        </div>
        
    </div>

    <div class="festival-body container-fluid">
    <div class="address">
            <p><?php echo trans('festivals/'.$festival['slug'].'.address'); ?></p>
        </div>
        <div class="row ">

            <div class="col-sm-6 col-sm-push-6">
                <div class="artists">                
                    <?php $__currentLoopData = $festival['artists']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $artists): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="row">
                        <ul class="list-inline">
                        <?php $__currentLoopData = $artists; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $artist): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($artist); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                    
                </div>
            </div>


            <div class="col-sm-6 col-sm-pull-6">                
                <div class="description">
                    <p><?php echo trans('festivals/'.$festival['slug'].'.description'); ?></p>
                </div>
            </div>

        </div>        
    </div>

    <?php if($festival['tickets']): ?>
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-12">
                <a href="<?php echo e($festival['tickets']); ?>" class="buy-tickets" target="_blank"><?php echo e(trans('text.festival-tickets-button')); ?></a>
            </div>
        </div>
    </div>
    <?php endif; ?>
</div> <!-- END .festival-wrapper -->


<div class="boxes">

    <div class="col-md-6 tickets-wrapper">
        <h2><?php echo e(trans('text.festival-tickets')); ?></h2>
        <p><?php echo trans('text.festival-tickets-description'); ?></p>
        <?php if($festival['tickets']): ?>
        <a href="<?php echo e($festival['tickets']); ?>" class="get-tickets"  target="_blank"><?php echo e(trans('text.festival-tickets-button')); ?></a>
        <?php else: ?>
        <h3><?php echo e(trans('text.festival-tickets-door')); ?></h3>
        <?php endif; ?>
    </div>
    <div class="col-md-6 watch-wrapper">
        <h2><?php echo e(trans('text.festival-reminder')); ?></h2>
        <p><?php echo trans('text.festival-reminder-description'); ?></p>
        <ul class="set-reminder">                    
            <li class="dropdown menu-reminder dropdown-reminder"
                data-title="<?php echo e(trans('text.stream-reminder-title',['city' => trans('festivals/'.$festival['slug'].'.city') ])); ?> "
                data-description="<?php echo e(trans('text.stream-reminder-text')); ?>"
                data-start="<?php echo e($festival['start']); ?>"
                data-end="<?php echo e($festival['end']); ?>"
                data-address="<?php echo e(trans('text.stream-reminder-text')); ?>"
                >
                <a href="#" class="dropdown-toggle" data-toggle="dropdown" data-hover="dropdown" role="button" aria-haspopup="true" aria-expanded="false"><?php echo e(trans('text.set-reminder')); ?></a>
            </li>
        </ul>
    </div>

</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>