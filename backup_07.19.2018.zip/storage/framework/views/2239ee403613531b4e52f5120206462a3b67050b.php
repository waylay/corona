<?php $__env->startSection('content'); ?>
    <div class="panel panel-primary">
        <div class="panel-heading">Welcome, <?php echo auth()->user()->name; ?>!</div>
        <div class="panel-body">
            <?php if(session('status')): ?>
                <div class="alert alert-warning alert-dismissible show" role="alert">
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                    <?php echo e(session('status')); ?>

                </div>
            <?php endif; ?>

            <table id="entries" class="display cell-border stripe compact responsive" cellspacing="0" width="100%">
                <thead>
                <tr>
                    <th class="text-filter">ID</th>
                    <th>Signed Up</th>
                    <th class="text-filter">Name</th>
                    <th class="text-filter">Email</th>
                    <th class="text-filter">Phone</th>
                    <th class="text-filter">Province</th>
                    <th>Birthday</th>
                    <th>Language</th>
                </tr>
                </thead>
                <tfoot>
                <tr>
                    <th class="id-text-filter">ID</th>
                    <th></th>
                    <th>Name</th>
                    <th>Email</th>
                    <th>Phone</th>
                    <th>Province</th>
                    <th></th>
                    <th></th>
                </tr>
                </tfoot>
            </table>

        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>