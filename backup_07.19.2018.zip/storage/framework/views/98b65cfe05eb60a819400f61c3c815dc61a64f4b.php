<?php $__env->startComponent('mail::message'); ?>
# <?php echo e(trans('email.heading')); ?>

<br>
## <?php echo e(trans('email.text-1')); ?>

<?php echo $__env->renderComponent(); ?>
