[<?php echo e($slot); ?>]
