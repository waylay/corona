<?php $__env->startSection('content'); ?>

<div class="container-fluid message" id="main">
    
    
    <div class="container">
        <div class="row">
        
            <h1><?php echo trans('text.festival'); ?> <span class="secondary"><?php echo trans('text.connected'); ?></span></h1>
            
            <div class="festival-date">
                <img src="/images/background-date-before.png" alt="">    
                <h1><?php echo trans('text.festival-date'); ?></h1>
                <img src="/images/background-date-after.png" alt="">    
            </div>


            <a href="https://www.eventbrite.ca/o/corona-sunsets-festival-17577225280" class="buy-tickets" target="_blank"><?php echo e(trans('text.festival-tickets-button')); ?></a>
            
        </div>
    </div> <!-- END .row -->



    <div class="container-fluid" id="play-trailer">
        <a class="play-trailer" href="<?php echo trans('text.trailer'); ?>" data-lity>
            <span><?php echo trans('text.play-trailer'); ?>&nbsp;</span>
            <img src="/images/play-trailer.png" alt="<?php echo trans('text.play-trailer'); ?>">
        </a>
    </div>  <!-- END #play-trailer -->
    
    
</div> <!-- END #festival -->



<div class="festival-list-wrapper">
    <div class="container-fluid" id="festival-list">
        <div class="row">
            <ul class="list-inline">
            <?php $__currentLoopData = $festivals; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slug => $festival): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><a href="#slide-<?php echo e($festival['id']); ?>" data-slide="<?php echo e($festival['id'] + 1); ?>"><?php echo e(trans('festivals/'.$festival['slug'].'.city')); ?></a></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    </div>  <!-- END #festival-list -->
</div>



<div class="slider-wrapper">
    <img src="/images/border-festivals.png">
    <ul id="festival-slider">
        <li class="slide">
            <div class="artists">
                <div class="row">
                    <ul class="list-inline">
                        <li><a href="/festival/whistler">KIDNAP</a></li>
                        <li><a href="/festival/whistler">CLAPTONE</a></li>
                        <li><a href="/festival/toronto">HOT CHIP DJ SET</a></li>                        
                    </ul>
                </div>
                <div class="row">
                    <ul class="list-inline">
                        <li><a href="/festival/quebec">CROOKED COLOURS</a></li>
                        <li><a href="/festival/winnipeg">CHRISTIAN MARTIN</a></li>
                        <li><a href="/festival/toronto">NITIN</a></li>
                    </ul>
                </div>
                <div class="row">
                    <ul class="list-inline">                        
                        <li><a href="/festival/toronto">THOMAS JACK</a></li>
                        <li><a href="/festival/toronto">Christian Löffler</a></li>
                        <li><a href="/festival/halifax">Amtrac</a></li>
                    </ul>
                </div>
            </div>

            <div class="slider-image" style="background: url('/images/slider-static.jpg') no-repeat center center / cover;">  
                <h1><?php echo trans('text.slider-static-headline'); ?></h1>              
                <a class="read-more" href="/more"> <?php echo e(trans('text.learn-more')); ?> </a>
            </div>
        </li>
        
        
        <?php $__currentLoopData = $festivals; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slug => $festival): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li class="slide" id="slide-<?php echo e($festival['id']); ?>">
            <div class="artists">
                
                <?php $__currentLoopData = $festival['artists']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $artists): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="row">
                    <ul class="list-inline">
                    <?php $__currentLoopData = $artists; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $artist): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><a href="/festival/<?php echo e($slug); ?>"><?php echo e($artist); ?></a></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    
            </div>
            <div class="slider-image" style="background: url('/images/slider-<?php echo e($slug); ?>.jpg') no-repeat center center / cover;">
                <h1><?php echo e(trans('festivals/'.$festival['slug'].'.city')); ?></h1>
                <a class="read-more" href="/festival/<?php echo e($slug); ?>"> <?php echo e(trans('text.learn-more')); ?> </a>
            </div>
        </li>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </ul>

</div>  <!-- END .slider-wrapper -->


<div class="boxes">

    <div class="col-md-6 tickets-wrapper">
        <h2><?php echo e(trans('text.festival-tickets')); ?></h2>
        <p><?php echo trans('text.festival-tickets-description'); ?></p>
        <a href="https://www.eventbrite.ca/o/corona-sunsets-festival-17577225280" target="_blank" class="get-tickets"><?php echo e(trans('text.festival-tickets-button')); ?></a>
    </div>
    <div class="col-md-6 watch-wrapper">
        <h2><?php echo e(trans('text.festival-reminder')); ?></h2>
        <p><?php echo e(trans('text.festival-reminder-description')); ?></p>
    </div>

</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>