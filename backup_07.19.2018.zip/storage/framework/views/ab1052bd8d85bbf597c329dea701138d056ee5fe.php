<?php $__env->startSection('content'); ?>

<div class="signup-form-wrapper">

    <div class="brand">
        <div class="logo">
            <img src="/images/logo-signup.png" alt="<?php echo e(trans('text.site-title')); ?>">
        </div>
    </div>


    <h2><?php echo trans('text.signup-title'); ?></h2>
    <h3><?php echo e(trans('text.signup-text-1')); ?></h3>
    <h3><?php echo e(trans('text.signup-text-2')); ?></h3>

    <form class="signup" id="signup" action="/process" method="POST" enctype="multipart/form-data" novalidate >
        <?php echo e(csrf_field()); ?>


        <p class="required-field">* <?php echo e(trans('form.required_field')); ?> </p>

        <div class="form-group">

            <input type="text" class="form-control <?php echo e($errors->has('firstname') ? 'is-invalid' :''); ?>" maxlength="30" tabindex="1" id="firstname" name="firstname"
                value="<?php echo e(old('firstname')); ?>"
                placeholder="<?php echo e(trans('form.firstname')); ?> *"
                data-msg-required="<?php echo e(trans('form.firstname_required')); ?>">

            <?php if($errors->has('firstname')): ?>
            <span id="firstname-error" class="error text-danger">
                    <?php echo e(trans('form.firstname_required')); ?>

            </span>
            <?php endif; ?>

        </div>

        <div class="form-group">

            <input type="text" class="form-control <?php echo e($errors->has('lastname') ? 'is-invalid' :''); ?>" maxlength="30"  id="lastname" name="lastname"
                value="<?php echo e(old('lastname')); ?>"
                placeholder="<?php echo e(trans('form.lastname')); ?> *"
                data-msg-required="<?php echo e(trans('form.lastname_required')); ?>">

            <?php if($errors->has('lastname')): ?>
            <span id="lastname-error" class="error text-danger">
                    <?php echo e(trans('form.lastname_required')); ?>

            </span>
            <?php endif; ?>

        </div>

        <div class="form-group">

            <input type="text" class="form-control <?php echo e($errors->has('email') ? 'is-invalid' :''); ?>" maxlength="50"   id="email" name="email"
                value="<?php echo e(old('email')); ?>"
                placeholder="<?php echo e(trans('form.email')); ?> *"
                data-msg-required="<?php echo e(trans('form.email_required')); ?>"
                data-msg-email="<?php echo e(trans('form.valid_email')); ?>">

            <?php if($errors->has('email')): ?>
            <span id="email-error" class="error text-danger">
                <?php echo e($errors->first('email')); ?>

            </span>
            <?php endif; ?>

        </div>

        <div class="form-group">
            <div class="selectdiv">
                <select class="form-control" id="province" name="province" data-msg-required="<?php echo e(trans('form.province_required')); ?>">
                    <option value=""><?php echo e(trans('form.province')); ?></option>
                    <option value="Alberta" <?php if(session('province') == 'Alberta'): ?> selected <?php endif; ?> >Alberta</option>
                    <option value="British Columbia" <?php if(session('province') == 'British Columbia'): ?> selected <?php endif; ?> >British Columbia</option>
                    <option value="Manitoba" <?php if(session('province') == 'Manitoba'): ?> selected <?php endif; ?> >Manitoba</option>
                    <option value="New Brunswick" <?php if(session('province') == 'New Brunswick'): ?> selected <?php endif; ?> >New Brunswick</option>
                    <option value="Newfoundland and Labrador" <?php if(session('province') == 'Newfoundland and Labrador'): ?> selected <?php endif; ?> >Newfoundland and Labrador</option>
                    <option value="Nova Scotia" <?php if(session('province') == 'Nova Scotia'): ?> selected <?php endif; ?> >Nova Scotia</option>
                    <option value="Northwest Territories" <?php if(session('province') == 'Northwest Territories'): ?> selected <?php endif; ?> >Northwest Territories</option>
                    <option value="Nunavut" <?php if(session('province') == 'Nunavut'): ?> selected <?php endif; ?> >Nunavut</option>
                    <option value="Ontario" <?php if(session('province') == 'Ontario'): ?> selected <?php endif; ?> >Ontario</option>
                    <option value="Quebec" <?php if(session('province') == 'Quebec'): ?> selected <?php endif; ?> >Quebec</option>
                    <option value="Saskatchewan" <?php if(session('province') == 'Saskatchewan'): ?> selected <?php endif; ?> >Saskatchewan</option>
                    <option value="Yukon" <?php if(session('province') == 'Yukon'): ?> selected <?php endif; ?> >Yukon</option>
                    <option value="Prince Edward Island" <?php if(session('province') == 'Prince Edward Island'): ?> selected <?php endif; ?> >Prince Edward Island</option>
                </select>
                <?php if($errors->has('province')): ?>
                <span id="province-error" class="error text-danger"><?php echo e(trans('form.province-error')); ?></span>
                <?php endif; ?>
            </div>
        </div>

        <div class="form-group">
            <label class="form-check-label" for="agree">
                <input class="form-check-input" type="checkbox" name="agree" id="agree" value="1" data-msg-required="<?php echo e(trans('form.must_agree')); ?>" >
                <span class="checkmark"></span>
                <p>* <?php echo e(trans('form.agree')); ?><br><a href="<?php echo e(trans('text.privacy-policy-link')); ?>" target="_blank"><?php echo e(trans('text.privacy-policy')); ?></a></p>
            </label>
            <?php if($errors->has('agree')): ?>
                <span id="agree-error" class="error text-danger"><?php echo e(trans('form.must_agree')); ?></span>
            <?php endif; ?>
        </div>

        <div class="form-group">
            <button class="enter text-uppercase" type="submit"><?php echo e(trans('form.signup')); ?></button>
        </div>
    </form>

</div> <!-- END .signup-form -->

<h2 class="connecting"><?php echo e(trans('text.connecting')); ?><br><a href="https://twitter.com/hashtag/coronasunsets" target="_blank"><?php echo e(trans('text.hashtag')); ?></a></h2>
<h3 class="get-inspired"><?php echo e(trans('text.get_inspired')); ?></h3>
<div id="video-wrapper">
<iframe width="1500" height="844" src="https://www.youtube.com/embed/u-Bz4QXwUqM?html5=1&amp;rel=0&amp;controls=1&amp;showinfo=0&amp;vq=hd1080&amp;modestbranding=1&amp;color=white&amp;iv_load_policy=3&amp;hl=<?php echo e(app()->getLocale()); ?>" frameborder="0" allow="autoplay; encrypted-media" allowfullscreen></iframe>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>